﻿#pragma once

#include "Runtime.h"

namespace Editor
{
	static uint32 g_WindowWidth = 1920;
	static uint32 g_WindowHeight = 1080;
}

using namespace Editor;