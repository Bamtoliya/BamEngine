﻿#include "Engine_Defines.h"

class Handle
{
public:

private:
	uint id;
};