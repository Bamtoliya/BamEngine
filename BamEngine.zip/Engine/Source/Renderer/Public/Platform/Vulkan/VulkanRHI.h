﻿//#include <RHI.h>
//#include <vulkan/vulkan.h>
//
//class VulkanRHI final : public RHI
//{
//private:
//	VulkanRHI() {}
//	virtual ~VulkanRHI() = default;
//	EResult Initialize(void* arg) override {}
//public:
//	virtual void Free() override;
//};
